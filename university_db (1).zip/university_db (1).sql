-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1:3306
-- Thời gian đã tạo: Th10 05, 2026 lúc 07:23 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `university_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `credits` int(11) NOT NULL DEFAULT 3,
  `department_id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL
) ;

--
-- Đang đổ dữ liệu cho bảng `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `title`, `description`, `credits`, `department_id`, `instructor_id`) VALUES
(1, 'MIS101', 'Introduction to Management Information Systems', 'Introduction to information systems and their role in business organizations.', 3, 1, 1),
(2, 'MIS201', 'Database Management', 'Fundamentals of relational databases, SQL and database design.', 3, 1, 1),
(3, 'FIN101', 'Principles of Finance', 'Introduction to financial management and basic financial concepts.', 3, 2, 2),
(4, 'MKT101', 'Marketing Fundamentals', 'Basic principles of marketing, customers and market research.', 3, 3, 3),
(5, 'CS101', 'Programming Fundamentals', 'Introduction to programming concepts, algorithms and problem solving.', 3, 4, 4),
(6, 'ENG101', 'Academic English', 'English communication and academic writing skills for university students.', 3, 5, 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `departments`
--

INSERT INTO `departments` (`id`, `code`, `name`, `created_at`) VALUES
(1, 'MIS', 'Management Information Systems', '2026-10-05 00:08:58'),
(2, 'FIN', 'Finance', '2026-10-05 00:08:58'),
(3, 'MKT', 'Marketing', '2026-10-05 00:08:58'),
(4, 'CS', 'Computer Science', '2026-10-05 00:08:58'),
(5, 'ENG', 'English Language', '2026-10-05 00:08:58');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `grade` decimal(3,2) DEFAULT NULL
) ;

--
-- Đang đổ dữ liệu cho bảng `enrollments`
--

INSERT INTO `enrollments` (`id`, `student_id`, `course_id`, `semester_id`, `grade`) VALUES
(1, 1, 1, 5, 3.80),
(2, 1, 2, 5, 3.70),
(3, 1, 6, 5, 3.60),
(4, 2, 1, 5, 3.50),
(5, 2, 4, 5, 3.80),
(6, 3, 5, 5, 3.20),
(7, 3, 1, 4, 3.40),
(8, 4, 4, 5, 3.90),
(9, 4, 6, 5, 3.70),
(10, 5, 3, 5, 3.10),
(11, 5, 1, 4, 3.30),
(12, 6, 6, 5, 3.95),
(13, 6, 4, 5, 3.85);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `instructors`
--

CREATE TABLE `instructors` (
  `id` int(11) NOT NULL,
  `instructor_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `instructors`
--

INSERT INTO `instructors` (`id`, `instructor_code`, `name`, `email`, `phone`, `department_id`) VALUES
(1, 'INS001', 'Nguyen Van An', 'an.nguyen@university.edu', '0901000001', 1),
(2, 'INS002', 'Tran Thi Lan', 'lan.tran@university.edu', '0901000002', 2),
(3, 'INS003', 'Le Minh Duc', 'duc.le@university.edu', '0901000003', 3),
(4, 'INS004', 'Pham Quoc Bao', 'bao.pham@university.edu', '0901000004', 4),
(5, 'INS005', 'Hoang Thu Ha', 'ha.hoang@university.edu', '0901000005', 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `semesters`
--

CREATE TABLE `semesters` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ;

--
-- Đang đổ dữ liệu cho bảng `semesters`
--

INSERT INTO `semesters` (`id`, `name`, `start_date`, `end_date`) VALUES
(1, 'Fall 2024', '2024-09-01', '2024-12-31'),
(2, 'Spring 2025', '2025-01-01', '2025-05-31'),
(3, 'Fall 2025', '2025-09-01', '2025-12-31'),
(4, 'Spring 2026', '2026-01-01', '2026-05-31'),
(5, 'Fall 2026', '2026-09-01', '2026-12-31');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `gpa` decimal(3,2) NOT NULL DEFAULT 0.00,
  `department_id` int(11) NOT NULL
) ;

--
-- Đang đổ dữ liệu cho bảng `students`
--

INSERT INTO `students` (`id`, `student_code`, `name`, `email`, `phone`, `gender`, `gpa`, `department_id`) VALUES
(1, '24070573', 'Vu Xuan Truong', '24070573@vnu.edu.vn', '0912000001', 'Male', 3.65, 1),
(2, '24070001', 'Nguyen Minh Anh', '24070001@vnu.edu.vn', '0912000002', 'Female', 3.42, 1),
(3, '24070002', 'Tran Quoc Bao', '24070002@vnu.edu.vn', '0912000003', 'Male', 3.20, 4),
(4, '24070003', 'Le Thu Trang', '24070003@vnu.edu.vn', '0912000004', 'Female', 3.78, 3),
(5, '24070004', 'Pham Duc Long', '24070004@vnu.edu.vn', '0912000005', 'Male', 3.15, 2),
(6, '24070005', 'Hoang Ngoc Mai', '24070005@vnu.edu.vn', '0912000006', 'Female', 3.90, 5);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_code` (`course_code`),
  ADD KEY `fk_course_department` (`department_id`),
  ADD KEY `fk_course_instructor` (`instructor_id`);

--
-- Chỉ mục cho bảng `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Chỉ mục cho bảng `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_enrollment` (`student_id`,`course_id`,`semester_id`),
  ADD KEY `fk_enrollment_course` (`course_id`),
  ADD KEY `fk_enrollment_semester` (`semester_id`);

--
-- Chỉ mục cho bảng `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `instructor_code` (`instructor_code`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_instructor_department` (`department_id`);

--
-- Chỉ mục cho bảng `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Chỉ mục cho bảng `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_code` (`student_code`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_student_department` (`department_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `instructors`
--
ALTER TABLE `instructors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `semesters`
--
ALTER TABLE `semesters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `fk_course_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_course_instructor` FOREIGN KEY (`instructor_id`) REFERENCES `instructors` (`id`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `fk_enrollment_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_enrollment_semester` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_enrollment_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `instructors`
--
ALTER TABLE `instructors`
  ADD CONSTRAINT `fk_instructor_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_student_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
